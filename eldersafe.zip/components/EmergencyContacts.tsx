import React, { useState } from 'react';
import { Contact } from '../types';
import { UserPlus, Trash2, Phone } from 'lucide-react';

interface EmergencyContactsProps {
  contacts: Contact[];
  setContacts: React.Dispatch<React.SetStateAction<Contact[]>>;
}

export const EmergencyContacts: React.FC<EmergencyContactsProps> = ({ contacts, setContacts }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');

  const addContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newPhone) return;
    
    const newContact: Contact = {
      id: Date.now().toString(),
      name: newName,
      phone: newPhone,
      relation: 'Family'
    };
    
    setContacts([...contacts, newContact]);
    setNewName('');
    setNewPhone('');
    setIsAdding(false);
  };

  const removeContact = (id: string) => {
    setContacts(contacts.filter(c => c.id !== id));
  };

  return (
    <div className="p-6 pb-32 max-w-lg mx-auto">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800">My Contacts</h2>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="bg-blue-600 text-white p-3 rounded-full hover:bg-blue-700 shadow-lg"
        >
          <UserPlus size={24} />
        </button>
      </div>

      {isAdding && (
        <form onSubmit={addContact} className="bg-white p-6 rounded-2xl shadow-lg border border-slate-100 mb-8 animate-in slide-in-from-top-4">
          <h3 className="text-lg font-bold mb-4">Add New Contact</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">Name</label>
              <input 
                type="text" 
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl text-lg focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="e.g. Son John"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-1">Phone Number</label>
              <input 
                type="tel" 
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl text-lg focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="e.g. 555-0123"
              />
            </div>
            <div className="flex gap-3 pt-2">
              <button 
                type="button" 
                onClick={() => setIsAdding(false)}
                className="flex-1 py-3 text-slate-600 font-bold bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="flex-1 py-3 text-white font-bold bg-blue-600 rounded-xl hover:bg-blue-700"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      )}

      <div className="space-y-4">
        {contacts.length === 0 && !isAdding && (
          <div className="text-center py-12 bg-slate-100 rounded-3xl border-2 border-dashed border-slate-200">
            <p className="text-slate-500 font-medium">No contacts added yet.</p>
            <p className="text-slate-400 text-sm mt-1">Tap the + button to add family or doctors.</p>
          </div>
        )}

        {contacts.map(contact => (
          <div key={contact.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-xl">
                {contact.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-800">{contact.name}</h3>
                <p className="text-slate-500 font-mono text-lg">{contact.phone}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <a 
                href={`tel:${contact.phone}`}
                className="p-3 bg-green-100 text-green-700 rounded-full hover:bg-green-200"
              >
                <Phone size={24} />
              </a>
              <button 
                onClick={() => removeContact(contact.id)}
                className="p-3 bg-red-50 text-red-500 rounded-full hover:bg-red-100"
              >
                <Trash2 size={24} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};