import React from 'react';
import { Home, Users, FileHeart, MessageCircleHeart } from 'lucide-react';
import { AppView } from '../types';

interface NavigationProps {
  currentView: AppView;
  setView: (view: AppView) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentView, setView }) => {
  const navItems = [
    { view: AppView.HOME, label: 'SOS', icon: Home, color: 'text-red-600' },
    { view: AppView.CONTACTS, label: 'Contacts', icon: Users, color: 'text-blue-600' },
    { view: AppView.MEDICAL_ID, label: 'Medical ID', icon: FileHeart, color: 'text-green-600' },
    { view: AppView.ASSISTANT, label: 'Helper', icon: MessageCircleHeart, color: 'text-purple-600' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-lg z-50 h-24 pb-safe">
      <div className="flex justify-around items-center h-full max-w-lg mx-auto px-2">
        {navItems.map((item) => {
          const isActive = currentView === item.view;
          const Icon = item.icon;
          
          return (
            <button
              key={item.view}
              onClick={() => setView(item.view)}
              className={`flex flex-col items-center justify-center w-full h-full space-y-1 active:scale-95 transition-transform ${
                isActive ? 'bg-slate-100' : ''
              }`}
            >
              <Icon 
                size={32} 
                className={`${isActive ? item.color : 'text-slate-400'}`} 
                strokeWidth={isActive ? 2.5 : 2}
              />
              <span className={`text-xs font-bold ${isActive ? 'text-slate-900' : 'text-slate-500'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};