import React, { useState, useEffect, useCallback } from 'react';
import { AlertTriangle, Phone, MapPin, X } from 'lucide-react';
import { LocationData, Contact } from '../types';

interface SOSButtonProps {
  contacts: Contact[];
}

export const SOSButton: React.FC<SOSButtonProps> = ({ contacts }) => {
  const [isActive, setIsActive] = useState(false);
  const [countdown, setCountdown] = useState(3);
  const [location, setLocation] = useState<LocationData>({
    latitude: null,
    longitude: null,
    error: null,
    loading: false
  });

  // Sound effect
  const playSiren = useCallback(() => {
    // A simple oscillating oscillator siren
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.type = 'sawtooth';
    osc.frequency.value = 440;
    
    // Siren modulation
    const now = ctx.currentTime;
    osc.frequency.setValueAtTime(600, now);
    osc.frequency.linearRampToValueAtTime(800, now + 0.5);
    osc.frequency.linearRampToValueAtTime(600, now + 1.0);
    
    // Loop it manually or just play a short burst. 
    // For this demo, a short loud burst is safer to avoid unstoppable noise.
    gain.gain.setValueAtTime(0.5, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 2);

    osc.start(now);
    osc.stop(now + 2);
  }, []);

  const fetchLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setLocation(prev => ({ ...prev, error: "Geolocation not supported" }));
      return;
    }

    setLocation(prev => ({ ...prev, loading: true }));
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          error: null,
          loading: false
        });
      },
      (error) => {
        setLocation(prev => ({ ...prev, error: error.message, loading: false }));
      }
    );
  }, []);

  const handlePress = () => {
    if (isActive) return;
    setCountdown(3);
    setIsActive(true);
  };

  const cancelSOS = () => {
    setIsActive(false);
    setCountdown(3);
  };

  useEffect(() => {
    let timer: any;
    if (isActive && countdown > 0) {
      timer = setTimeout(() => setCountdown(c => c - 1), 1000);
    } else if (isActive && countdown === 0) {
      // Trigger Actual SOS Mode
      playSiren();
      fetchLocation();
    }
    return () => clearTimeout(timer);
  }, [isActive, countdown, playSiren, fetchLocation]);

  if (isActive && countdown === 0) {
    // EMERGENCY MODE UI
    return (
      <div className="fixed inset-0 bg-red-600 z-50 flex flex-col items-center justify-center p-6 animate-pulse-slow">
        <div className="bg-white p-6 rounded-3xl shadow-2xl w-full max-w-md text-center space-y-8">
          
          <div className="flex justify-between items-center border-b pb-4">
            <h2 className="text-3xl font-black text-red-600 flex items-center gap-2">
              <AlertTriangle size={32} />
              EMERGENCY
            </h2>
            <button 
              onClick={cancelSOS}
              className="p-2 bg-slate-200 rounded-full"
            >
              <X size={24} />
            </button>
          </div>

          <div className="space-y-2">
            <p className="text-lg font-semibold text-slate-700">Your Location</p>
            {location.loading ? (
              <p className="animate-pulse">Locating...</p>
            ) : location.error ? (
              <p className="text-red-500 text-sm">Could not find location</p>
            ) : location.latitude ? (
              <div className="bg-slate-100 p-4 rounded-xl flex items-center justify-center gap-3">
                <MapPin className="text-red-500" />
                <div className="text-left">
                  <div className="font-mono text-lg font-bold">{location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}</div>
                  <a 
                    href={`https://www.google.com/maps?q=${location.latitude},${location.longitude}`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-blue-600 underline text-sm"
                  >
                    View on Map
                  </a>
                </div>
              </div>
            ) : null}
          </div>

          <div className="grid gap-4">
            <a 
              href="tel:911" // Or 112, localized
              className="w-full bg-red-600 hover:bg-red-700 text-white font-black text-2xl py-6 rounded-2xl flex items-center justify-center gap-3 shadow-lg active:scale-95 transition-transform"
            >
              <Phone size={32} />
              CALL 911
            </a>
            
            {contacts.map(contact => (
              <a
                key={contact.id}
                href={`sms:${contact.phone}?body=EMERGENCY! I need help. My location is: https://maps.google.com/?q=${location.latitude},${location.longitude}`}
                className="w-full bg-slate-800 text-white font-bold text-xl py-4 rounded-2xl flex items-center justify-center gap-3 active:scale-95 transition-transform"
              >
                <Phone size={24} />
                Alert {contact.name}
              </a>
            ))}
            
            {contacts.length === 0 && (
               <p className="text-slate-500 text-sm italic">Add contacts in the Contacts tab to message them quickly.</p>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center h-full space-y-8 animate-in fade-in duration-500">
      <div className="text-center space-y-2 max-w-xs">
        <h1 className="text-3xl font-black text-slate-800">Need Help?</h1>
        <p className="text-slate-500 text-lg">Press and hold the button below for 3 seconds.</p>
      </div>

      <button
        onMouseDown={handlePress}
        onTouchStart={handlePress}
        onMouseUp={cancelSOS}
        onTouchEnd={cancelSOS}
        onMouseLeave={cancelSOS}
        className={`
          relative w-64 h-64 rounded-full shadow-2xl flex items-center justify-center transition-all duration-200
          ${isActive 
            ? 'bg-red-500 scale-95 ring-8 ring-red-200' 
            : 'bg-gradient-to-br from-red-500 to-red-600 hover:scale-105 hover:shadow-red-200/50'
          }
        `}
      >
        {isActive ? (
          <div className="text-white text-6xl font-black tabular-nums animate-ping-slow">
            {countdown}
          </div>
        ) : (
          <div className="flex flex-col items-center text-white">
            <span className="text-6xl font-black tracking-widest">SOS</span>
            <span className="text-sm font-semibold opacity-80 mt-2 uppercase tracking-wide">Emergency</span>
          </div>
        )}
      </button>

      {isActive && countdown > 0 && (
        <p className="text-red-600 font-bold text-xl animate-pulse">Keep holding...</p>
      )}
    </div>
  );
};