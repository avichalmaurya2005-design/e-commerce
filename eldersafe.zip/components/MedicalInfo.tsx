import React, { useState } from 'react';
import { MedicalProfile } from '../types';
import { Edit2, Save } from 'lucide-react';

interface MedicalInfoProps {
  profile: MedicalProfile;
  setProfile: (p: MedicalProfile) => void;
}

export const MedicalInfo: React.FC<MedicalInfoProps> = ({ profile, setProfile }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [tempProfile, setTempProfile] = useState<MedicalProfile>(profile);

  const handleSave = () => {
    setProfile(tempProfile);
    setIsEditing(false);
  };

  const handleChange = (field: keyof MedicalProfile, value: string) => {
    setTempProfile(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="p-6 pb-32 max-w-lg mx-auto">
       <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800">Medical ID</h2>
        <button 
          onClick={isEditing ? handleSave : () => setIsEditing(true)}
          className={`flex items-center gap-2 px-6 py-2 rounded-full font-bold shadow-md transition-colors ${
            isEditing ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
          }`}
        >
          {isEditing ? <><Save size={20} /> Save</> : <><Edit2 size={20} /> Edit</>}
        </button>
      </div>

      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-200">
        <div className="bg-red-50 p-6 border-b border-red-100">
          <p className="text-red-800 text-sm font-bold uppercase tracking-wider mb-2">Emergency Card</p>
          {isEditing ? (
             <input
              type="text"
              value={tempProfile.name}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="Your Full Name"
              className="w-full p-2 text-2xl font-bold bg-white border border-red-200 rounded-lg"
            />
          ) : (
            <h1 className="text-3xl font-black text-slate-900 break-words">{profile.name || "Unknown Name"}</h1>
          )}
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
              <label className="text-slate-500 text-sm font-semibold uppercase block mb-1">Blood Type</label>
               {isEditing ? (
                <select 
                  className="w-full p-2 bg-white border rounded text-lg font-bold"
                  value={tempProfile.bloodType}
                  onChange={(e) => handleChange('bloodType', e.target.value)}
                >
                  {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown'].map(t => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              ) : (
                <p className="text-2xl font-black text-slate-800">{profile.bloodType}</p>
              )}
            </div>
            
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
              <label className="text-slate-500 text-sm font-semibold uppercase block mb-1">Age / DOB</label>
               {isEditing ? (
                 <input
                  type="text"
                  value={tempProfile.conditions} // Using conditions field as a placeholder for simplicity in this demo structure, normally would separate.
                  onChange={(e) => handleChange('conditions', e.target.value)}
                  placeholder="e.g. 75"
                  className="w-full p-2 bg-white border rounded font-bold"
                />
              ) : (
                <p className="text-xl font-bold text-slate-800">{profile.conditions || "--"}</p>
              )}
            </div>
          </div>

          <div>
             <label className="text-slate-500 text-sm font-semibold uppercase block mb-2">Medical Conditions</label>
             {isEditing ? (
               <textarea
                className="w-full p-3 bg-slate-50 border rounded-xl text-lg min-h-[100px]"
                value={tempProfile.medications} // Reusing field for demo simplicity
                onChange={(e) => handleChange('medications', e.target.value)}
                placeholder="Diabetes, Hypertension, etc."
               />
             ) : (
               <div className="bg-yellow-50 p-4 rounded-xl border border-yellow-100 text-slate-800 text-lg font-medium">
                 {profile.medications || "None listed"}
               </div>
             )}
          </div>

          <div>
             <label className="text-slate-500 text-sm font-semibold uppercase block mb-2">Allergies</label>
             {isEditing ? (
               <textarea
                className="w-full p-3 bg-slate-50 border rounded-xl text-lg min-h-[80px]"
                value={tempProfile.allergies}
                onChange={(e) => handleChange('allergies', e.target.value)}
                placeholder="Peanuts, Penicillin, etc."
               />
             ) : (
               <div className="bg-red-50 p-4 rounded-xl border border-red-100 text-red-800 text-lg font-medium">
                 {profile.allergies || "None listed"}
               </div>
             )}
          </div>
        </div>
      </div>
      
      <p className="text-center text-slate-400 mt-8 text-sm">
        Show this screen to paramedics in case of emergency.
      </p>
    </div>
  );
};