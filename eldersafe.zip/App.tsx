import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { SOSButton } from './components/SOSButton';
import { EmergencyContacts } from './components/EmergencyContacts';
import { MedicalInfo } from './components/MedicalInfo';
import { Assistant } from './components/Assistant';
import { AppView, Contact, MedicalProfile } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.HOME);
  
  // Persist contacts in local storage
  const [contacts, setContacts] = useState<Contact[]>(() => {
    const saved = localStorage.getItem('elderSafeContacts');
    return saved ? JSON.parse(saved) : [];
  });

  // Persist medical profile
  const [medicalProfile, setMedicalProfile] = useState<MedicalProfile>(() => {
    const saved = localStorage.getItem('elderSafeMedical');
    return saved ? JSON.parse(saved) : {
      name: '',
      bloodType: 'Unknown',
      conditions: '',
      medications: '',
      allergies: ''
    };
  });

  useEffect(() => {
    localStorage.setItem('elderSafeContacts', JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem('elderSafeMedical', JSON.stringify(medicalProfile));
  }, [medicalProfile]);

  const renderView = () => {
    switch (currentView) {
      case AppView.HOME:
        return <SOSButton contacts={contacts} />;
      case AppView.CONTACTS:
        return <EmergencyContacts contacts={contacts} setContacts={setContacts} />;
      case AppView.MEDICAL_ID:
        return <MedicalInfo profile={medicalProfile} setProfile={setMedicalProfile} />;
      case AppView.ASSISTANT:
        return <Assistant />;
      default:
        return <SOSButton contacts={contacts} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-24">
      {/* Main Content Area */}
      <main className="h-full pt-6">
        {renderView()}
      </main>

      {/* Persistent Navigation */}
      <Navigation currentView={currentView} setView={setCurrentView} />
    </div>
  );
};

export default App;