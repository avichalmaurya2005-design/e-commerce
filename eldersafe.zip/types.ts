export interface Contact {
  id: string;
  name: string;
  phone: string;
  relation: string;
}

export interface MedicalProfile {
  name: string;
  bloodType: string;
  conditions: string;
  medications: string;
  allergies: string;
}

export interface LocationData {
  latitude: number | null;
  longitude: number | null;
  error: string | null;
  loading: boolean;
}

export enum AppView {
  HOME = 'HOME',
  CONTACTS = 'CONTACTS',
  MEDICAL_ID = 'MEDICAL_ID',
  ASSISTANT = 'ASSISTANT'
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  isThinking?: boolean;
}