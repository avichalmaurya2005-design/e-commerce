import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

// Initialize the client. API_KEY is injected by the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are "ElderSafe Companion", a helpful, calm, and clear assistant for an elderly person.
1. Keep your answers SHORT (max 2-3 sentences unless asked for more).
2. Use SIMPLE words. Avoid medical jargon.
3. If the user mentions a life-threatening emergency (chest pain, fallen, bleeding), IMMEDIATELY tell them to press the red SOS button or call emergency services. Do not try to treat serious emergencies yourself.
4. Be polite, respectful, and patient.
5. Format your text clearly.
`;

export const sendMessageToGemini = async (
  history: ChatMessage[],
  newMessage: string
): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    
    // Transform internal history to Gemini format if needed, 
    // but for simple single-turn or short context, we can just use generateContent with the history as context 
    // or use the chat API. Let's use the chat API for better context handling.
    
    const chat = ai.chats.create({
      model: model,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
      history: history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.text }]
      }))
    });

    const result = await chat.sendMessage({
      message: newMessage
    });

    return result.text || "I'm sorry, I couldn't understand that. Please try again.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I am having trouble connecting to the internet. Please check your connection.";
  }
};